<?php
// Heading
$_['heading_title'] = 'Página não encontrada';

// Text
$_['text_error']    = 'A página que você está procurando, não foi encontrada.';