<?php
// Heading
$_['heading_title'] = 'Total de clientes';

// Text
$_['text_view']     = 'Ver mais...';