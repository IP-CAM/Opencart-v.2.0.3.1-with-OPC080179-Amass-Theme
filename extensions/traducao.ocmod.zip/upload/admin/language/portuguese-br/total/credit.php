<?php
// Heading
$_['heading_title']    = 'Crédito na loja';

// Text
$_['text_total']       = 'Total de pedidos';
$_['text_success']	   = 'Crédito na loja modificado com sucesso!';
$_['text_edit']        = 'Configurações do Crédito na loja';

// Entry
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o Crédito na loja!';