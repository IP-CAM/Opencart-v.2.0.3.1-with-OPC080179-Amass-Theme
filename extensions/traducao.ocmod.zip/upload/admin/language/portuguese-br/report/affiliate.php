<?php
// Heading
$_['heading_title']     = 'Relatório de comissões de afiliados';

// Text
$_['text_list']         = 'Listando comissões de afiliados';

// Column
$_['column_affiliate']  = 'Afiliado';
$_['column_email']      = 'E-mail';
$_['column_status']     = 'Situação';
$_['column_commission'] = 'Comissão';
$_['column_orders']     = 'Pedidos';
$_['column_total']      = 'Total';
$_['column_action']     = 'Ação';

// Entry
$_['entry_date_start']  = 'Data inicial';
$_['entry_date_end']    = 'Data final';