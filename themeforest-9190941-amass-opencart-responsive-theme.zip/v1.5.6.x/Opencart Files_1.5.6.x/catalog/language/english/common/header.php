<?php
// Text
$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Wish List (%s)';
$_['text_shopping_cart']  = 'Shopping Cart';
$_['text_search']         = 'Search';
$_['text_welcome']        = 'Welcome <a href="%s">Login</a> <a href="%s">Create an account</a>';
$_['text_logged']         = 'Welcome <a href="%s">%s</a> <a href="%s" class="logout">Logout</a>';
$_['text_account']        = 'My Account';
$_['text_checkout']       = 'Checkout';
?>