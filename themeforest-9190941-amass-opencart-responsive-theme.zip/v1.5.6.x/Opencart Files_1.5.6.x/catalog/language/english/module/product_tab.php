<?php
// Heading 
$_['heading_title'] = 'Our Products';

$_['tab_latest'] = 'Latest';
$_['tab_bestseller'] = 'Bestseller';
$_['tab_featured'] = 'Featured';
$_['tab_special'] = 'Special';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>