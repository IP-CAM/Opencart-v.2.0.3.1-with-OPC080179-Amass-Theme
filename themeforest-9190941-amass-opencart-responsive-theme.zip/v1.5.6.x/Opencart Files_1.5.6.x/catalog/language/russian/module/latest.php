<?php
// Heading 
$_['heading_title']	= 'Новые поступления';

// Text
$_['text_reviews']	= 'Отзывов: %s';
?>