<?php
// Heading 
$_['heading_title'] = 'Корзина покупок';

// Text
$_['text_items']    = '%s <span>товар(ов)</span>';
$_['text_empty']    = 'Корзина покупок пуста!';
$_['text_cart']     = 'Просмотр корзины';
$_['text_checkout'] = 'Оформить заказ';

$_['text_payment_profile'] = 'Оплатить профиль';
?>