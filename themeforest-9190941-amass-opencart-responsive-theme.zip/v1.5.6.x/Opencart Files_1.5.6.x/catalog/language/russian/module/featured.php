<?php
// Heading 
$_['heading_title'] = 'Рекомендуем';

// Text
$_['text_reviews']	= 'Отзывов: %s';
?>