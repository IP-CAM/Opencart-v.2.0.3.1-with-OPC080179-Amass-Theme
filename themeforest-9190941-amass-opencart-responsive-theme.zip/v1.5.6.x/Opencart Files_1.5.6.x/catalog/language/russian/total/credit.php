<?php
$_['text_credit']   = 'Кредит Магазина:';
$_['text_order_id'] = 'Номер заказа (ID): #%s';
?>