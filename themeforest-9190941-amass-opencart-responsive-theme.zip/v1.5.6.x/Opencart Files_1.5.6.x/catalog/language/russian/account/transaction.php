<?php
// Heading 
$_['heading_title']      = 'История платежей';

// Column
$_['column_date_added']  = 'Дата';
$_['column_description'] = 'Описание';
$_['column_amount']      = 'Сумма (%s)';

// Text
$_['text_account']       = 'Личный Кабинет';
$_['text_transaction']   = 'Ваши платежи';
$_['text_total']         = 'Ваш текущий баланс:';
$_['text_empty']         = 'У Вас не было платежей!';
?>