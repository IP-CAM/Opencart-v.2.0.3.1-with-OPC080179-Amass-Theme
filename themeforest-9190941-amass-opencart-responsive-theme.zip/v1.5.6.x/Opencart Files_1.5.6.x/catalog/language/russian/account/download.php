<?php
// Heading 
$_['heading_title']   = 'Файлы для скачивания';

// Text
$_['text_account']    = 'Личный Кабинет';
$_['text_downloads']  = 'Файлы для скачивания';
$_['text_order']      = '№ заказа:';
$_['text_date_added'] = 'Добавлено:';
$_['text_name']       = 'Имя:';
$_['text_remaining']  = 'Осталось:';
$_['text_size']       = 'Размер:';
$_['text_empty']      = 'У Вас не было заказов с файлами для скачивания!';
?>