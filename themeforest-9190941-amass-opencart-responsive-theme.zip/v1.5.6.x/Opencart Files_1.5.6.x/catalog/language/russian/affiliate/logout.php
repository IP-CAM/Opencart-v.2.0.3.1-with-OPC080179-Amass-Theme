<?php
// Heading 
$_['heading_title'] = 'Выход из кабинета партнера';

// Text
$_['text_message']  = '<p>Вы вышли из кабинета партнера.</p>';
$_['text_account']  = 'Кабинет партнера';
$_['text_logout']   = 'Выход';
?>