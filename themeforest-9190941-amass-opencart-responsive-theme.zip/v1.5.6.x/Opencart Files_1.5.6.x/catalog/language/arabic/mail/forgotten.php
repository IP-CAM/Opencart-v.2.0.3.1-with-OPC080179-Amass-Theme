<?php
// Text
$_['text_subject']    = '%s - كلمة المرور الجديدة';
$_['text_greeting']   = 'قد تم طلب كلمة مرور جديدة من %s.';
$_['text_password']   = 'كلمة المرور الجديدة هي:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>