<?php
// Text
$_['text_information']  = 'معلومات';
$_['text_service']      = 'خدمة العملاء';
$_['text_extra']        = 'إضافات';
$_['text_contact']      = 'اتصل بنا';
$_['text_return']       = 'إرجاع منتج';
$_['text_sitemap']      = 'خريطة الموقع';
$_['text_manufacturer'] = 'الماركات';
$_['text_voucher']      = 'قسائم الإهداءات';
$_['text_affiliate']    = 'نظام الترويج';
$_['text_special']      = 'العروض المميزة';
$_['text_account']      = 'الحساب';
$_['text_order']        = 'سجل الطلبات';
$_['text_wishlist']     = 'القائمة المفضلة';
$_['text_newsletter']   = 'النشرة البريدية';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a> %s &copy; %s تعريب: <a href="http://www.alfnyhost.com">الفني هوست</a>';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>