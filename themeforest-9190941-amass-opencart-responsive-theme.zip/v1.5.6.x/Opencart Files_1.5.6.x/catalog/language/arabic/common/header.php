<?php
// Text
$_['text_home']     = 'الرئيسية';
$_['text_wishlist'] = 'القائمة المفضلة (%s)';
$_['text_cart']     = 'سلة التسوق';
$_['text_items']    = '%s صنف - %s';
$_['text_search']   = 'بحث';
$_['text_welcome']  = 'مرحباً بالزائر يمكنك <a href="%s">تسجيل الدخول</a> أو <a href="%s">إنشاء حساب</a>.';
$_['text_logged']   = 'تم تسجيل دخول باسم <a href="%s">%s</a> <b>(</b> <a href="%s">تسجيل الخروج</a> <b>)</b>';
$_['text_account']  = 'الحساب';
$_['text_checkout'] = 'التقدم للشراء';
$_['text_language'] = 'اللغة';
$_['text_currency'] = 'العملة';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>