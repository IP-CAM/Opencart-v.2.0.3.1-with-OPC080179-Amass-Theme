<?php
// Heading
$_['heading_title']     = 'صيانة الموقع';

// Text
$_['text_maintenance']  = 'صيانة الموقع';
$_['text_message']      = '<h1 style="text-align:center;">حاليا نقوم بأعمال الصيانة. <br/>سنعود في أقرب وقت ممكن. يرجى العودة لاحقا.</h1>';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>