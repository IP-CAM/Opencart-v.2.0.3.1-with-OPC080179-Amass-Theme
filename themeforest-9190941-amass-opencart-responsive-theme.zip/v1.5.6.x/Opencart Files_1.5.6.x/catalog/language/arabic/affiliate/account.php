<?php
// Heading 
$_['heading_title']        = 'حساب الترويج';

// Text
$_['text_account']         = 'الحساب';
$_['text_my_account']      = 'حساب الترويج';
$_['text_my_tracking']     = 'معلومات التتبع';
$_['text_my_transactions'] = 'التحويلات';
$_['text_edit']            = 'تحرير معلومات الحساب';
$_['text_password']        = 'تغيير كلمة المرور';
$_['text_payment']         = 'تغيير تفصيل الدفع';
$_['text_tracking']        = 'رمز تتبع عملاء المروج ';
$_['text_transaction']     = 'عرض سجل التحويلات';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>