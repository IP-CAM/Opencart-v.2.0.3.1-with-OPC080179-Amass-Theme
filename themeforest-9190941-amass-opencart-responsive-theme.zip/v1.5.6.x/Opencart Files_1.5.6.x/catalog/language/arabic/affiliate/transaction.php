<?php
// Heading 
$_['heading_title']      = 'التحويلات';

// Column
$_['column_date_added']  = 'تاريخ الإضافة';
$_['column_description'] = 'الوصف';
$_['column_amount']      = 'المبلغ (%s)';

// Text
$_['text_account']       = 'الحساب';
$_['text_transaction']   = 'التحويلات';
$_['text_balance']       = 'الرصيد الحالي:';
$_['text_empty']         = 'لا يوجد لديك أي تحويلات!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>