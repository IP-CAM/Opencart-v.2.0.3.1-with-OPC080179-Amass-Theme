<?php
// Heading 
$_['heading_title']  = 'تغيير كلمة المرور';

// Text
$_['text_account']   = 'الحساب';
$_['text_password']  = 'كلمة المرور';
$_['text_success']   = 'تم تحديث كلمة المرور بنجاح.';

// Entry
$_['entry_password'] = 'كلمة المرور:';
$_['entry_confirm']  = 'تأكيد كلمة المرور:';

// Error
$_['error_password'] = 'كلمة المرور يجب أن تكون أكثر من 3 وأقل من 20 حرفا!';
$_['error_confirm']  = 'لم تتطابق كلمة المرور الرجاء إعادة كتبته مرة أخرى!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>