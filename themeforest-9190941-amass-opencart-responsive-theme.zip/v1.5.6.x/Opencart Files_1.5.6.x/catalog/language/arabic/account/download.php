<?php
// Heading 
$_['heading_title']   = 'حساب التحميل';

// Text
$_['text_account']    = 'الحساب';
$_['text_downloads']  = 'التحميل';
$_['text_order']      = 'رقم الطلب:';
$_['text_date_added'] = 'تاريخ الإضافة:';
$_['text_name']       = 'الاسم:';
$_['text_remaining']  = 'المتبقي:';
$_['text_size']       = 'الحجم:';
$_['text_download']   = 'التحميل';
$_['text_empty']      = 'لم تقم بطلب أية خدمة للتحميل حتى الآن!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>