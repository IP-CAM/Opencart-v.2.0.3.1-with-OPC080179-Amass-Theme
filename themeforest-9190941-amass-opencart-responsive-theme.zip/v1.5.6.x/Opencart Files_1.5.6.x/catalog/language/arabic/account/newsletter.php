<?php
// Heading 
$_['heading_title']    = 'الاشتراك في النشرة البريدية';

// Text
$_['text_account']     = 'الحساب';
$_['text_newsletter']  = 'النشرة البريدية';
$_['text_success']     = 'قد تم تحديث النشرة البريدية بنجاح!';

// Entry
$_['entry_newsletter'] = 'هل تريد الاشتراك';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>