<?php
// Heading 
$_['heading_title']      = 'التحويلات';

// Column
$_['column_date_added']  = 'تاريخ الإضافة';
$_['column_description'] = 'الوصف';
$_['column_amount']      = 'المبلغ (%s)';

// Text
$_['text_account']       = 'الحساب';
$_['text_transaction']   = 'التحويلات';
$_['text_total']         = 'الرصيد الحالي هو:';
$_['text_empty']         = 'ليس لديك أي تحويلات!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>