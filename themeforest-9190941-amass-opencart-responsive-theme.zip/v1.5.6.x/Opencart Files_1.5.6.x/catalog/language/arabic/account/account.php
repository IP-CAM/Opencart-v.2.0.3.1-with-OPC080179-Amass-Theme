<?php
// Heading 
$_['heading_title']      = 'منطقة العميل';

// Text
$_['text_account']       = 'الحساب';
$_['text_my_account']    = 'الحساب';
$_['text_my_orders']     = 'الطلبات';
$_['text_my_newsletter'] = 'النشرة البريدية';
$_['text_edit']          = 'تحرير معلومات الحساب';
$_['text_password']      = 'تغيير كلمة المرور';
$_['text_address']       = 'تعديل معلومات دفتر العناوين';
$_['text_wishlist']      = 'تعديل القائمة المفضلة';
$_['text_order']         = 'عرض سجل الطلبات';
$_['text_download']      = 'التحميلات';
$_['text_reward']        = 'نقاط المكافآت'; 
$_['text_return']        = 'عرض الطلبات المرجعة'; 
$_['text_transaction']   = 'التحويلات'; 
$_['text_newsletter']    = 'الاشتراك أو إلغاء الاشتراك في النشرة البريدية';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>