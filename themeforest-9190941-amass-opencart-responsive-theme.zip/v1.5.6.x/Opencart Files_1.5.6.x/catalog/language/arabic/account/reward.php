<?php
// Heading 
$_['heading_title']      = 'نقاط المكافآت';

// Column
$_['column_date_added']  = 'تاريخ الإضافة';
$_['column_description'] = 'الوصف';
$_['column_points']      = 'النقاط';

// Text
$_['text_account']       = 'الحساب';
$_['text_reward']        = 'نقاط المكافآت';
$_['text_total']         = 'العدد الإجمالي للنقاط المكافآت هو:';
$_['text_empty']         = 'ليس لديك أي نقاط مكافآت!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>