<?php
// Heading
$_['heading_title']    = 'خريطة الموقع';
 
// Text
$_['text_special']     = 'العروض المميزة';
$_['text_account']     = 'الحساب';
$_['text_edit']        = 'معلومات الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_address']     = 'دفتر العناوين';
$_['text_history']     = 'سجل الطلبات';
$_['text_download']    = 'التحميلات';
$_['text_cart']        = 'سلة التسوق';
$_['text_checkout']    = 'التقدم للشراء';
$_['text_search']      = 'بحث';
$_['text_information'] = 'معلومات';
$_['text_contact']     = 'اتصل بنا';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>