<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'الوزن:'; 
$_['text_insurance']   = 'التامين حتى:';   
$_['text_time']        = 'الوقت المحدد: في غضون 48 ساعة'; 

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>