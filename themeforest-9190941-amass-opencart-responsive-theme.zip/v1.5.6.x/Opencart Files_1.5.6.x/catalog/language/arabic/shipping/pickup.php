<?php
// Text
$_['text_title']       = 'التسليم';
$_['text_description'] = 'التسليم من المحل';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>