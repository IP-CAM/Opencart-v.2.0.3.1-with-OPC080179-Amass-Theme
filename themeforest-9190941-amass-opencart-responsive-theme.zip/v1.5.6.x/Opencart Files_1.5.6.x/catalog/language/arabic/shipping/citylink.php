<?php
// Text
$_['text_title']  = 'Citylink';
$_['text_weight'] = 'الوزن:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>