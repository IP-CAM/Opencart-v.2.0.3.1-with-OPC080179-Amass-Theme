<?php
// Text
$_['text_title']       = 'الشحن المجاني';
$_['text_description'] = 'الشحن المجاني';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>