<?php
// Text
$_['text_title']       = 'سعر ثابت';
$_['text_description'] = 'الشحن بسعر ثابت';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>