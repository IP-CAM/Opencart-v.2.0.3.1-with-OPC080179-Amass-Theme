<?php
// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'الوزن:';
$_['text_eta']    = 'الوقت المقدر:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>