<?php
// Text
$_['text_low_order_fee'] = 'رسوم الطلب المخفض:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>