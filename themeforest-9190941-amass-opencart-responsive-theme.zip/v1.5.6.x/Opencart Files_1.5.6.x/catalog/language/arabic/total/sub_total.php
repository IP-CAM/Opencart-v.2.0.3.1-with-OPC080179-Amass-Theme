<?php
// Text
$_['text_sub_total'] = 'المبلغ الإجمالي:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>