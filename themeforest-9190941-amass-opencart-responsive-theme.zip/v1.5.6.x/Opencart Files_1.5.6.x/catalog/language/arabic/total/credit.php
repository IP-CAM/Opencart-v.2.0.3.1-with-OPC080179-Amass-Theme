<?php
$_['text_credit']   = 'رصيد المتجر:';
$_['text_order_id'] = 'رقم الطلب: #%s';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>