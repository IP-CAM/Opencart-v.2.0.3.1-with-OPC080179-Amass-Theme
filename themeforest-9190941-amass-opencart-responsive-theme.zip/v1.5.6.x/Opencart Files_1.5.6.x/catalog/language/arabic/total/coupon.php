<?php
// Heading 
$_['heading_title'] = 'تطبيق رمز الخصم';

// Text
$_['text_coupon']   = 'القسيمة(%s):';
$_['text_success']  = 'تم تطبيق قسيمة الخصم بنجاح!';

// Entry
$_['entry_coupon']  = 'ادخل رقم القسيمة هنا:';

// Error
$_['error_coupon']  = 'القسيمة إما غير صالح، منتهية الصلاحية أو تجوزت حد الاستخدام!';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>