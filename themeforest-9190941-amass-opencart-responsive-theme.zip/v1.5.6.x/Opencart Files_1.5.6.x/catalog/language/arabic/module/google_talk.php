<?php
// Heading 
$_['heading_title']  = 'المحادثة المباشرة';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>