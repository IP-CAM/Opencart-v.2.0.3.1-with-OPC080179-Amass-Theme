<?php
// Heading 
$_['heading_title']  = 'حاليا في المتجر';

// Text
$_['text_reviews']  = 'من أفضل %s تقييمات.'; 

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>