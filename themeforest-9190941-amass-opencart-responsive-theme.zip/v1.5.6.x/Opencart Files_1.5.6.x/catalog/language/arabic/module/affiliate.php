<?php
// Heading 
$_['heading_title']    = 'نظام الترويج';

// Text
$_['text_register']    = 'التسجيل';
$_['text_login']       = 'تسجيل الدخول';
$_['text_logout']      = 'تسجيل الخروج';
$_['text_forgotten']   = 'نسيت كلمة المرور';
$_['text_account']     = 'الحساب';
$_['text_edit']        = 'تحرير الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_payment']     = 'خيارات الدفع';
$_['text_tracking']    = 'تتبع نظام الترويج';
$_['text_transaction'] = 'التحويلات';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>