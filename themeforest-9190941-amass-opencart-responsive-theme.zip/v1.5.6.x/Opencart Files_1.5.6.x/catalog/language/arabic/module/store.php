<?php
// Heading 
$_['heading_title'] = 'اختر متجر';

// Text
$_['text_default']  = 'الافتراضي';
$_['text_store']    = 'يرجى اختيار المتجر الذي تريد زيارته.';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>