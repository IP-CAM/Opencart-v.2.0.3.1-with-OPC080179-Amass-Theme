<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading 
$_['heading_title'] = 'سلة الشراء';

// Text
$_['text_items']    = '%s <span>صنف</span>';
$_['text_empty']    = 'سلة الشراء فارغة!';
$_['text_cart']     = 'معاينة السلة';
$_['text_checkout'] = 'إنهاء الطلب';

$_['text_payment_profile'] = 'المدفوعات';
?>