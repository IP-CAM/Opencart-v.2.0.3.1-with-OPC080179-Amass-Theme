<?php
// Heading 
$_['heading_title']    = 'الحساب';

// Text
$_['text_register']    = 'التسجيل';
$_['text_login']       = 'تسجيل الدخول';
$_['text_logout']      = 'تسجيل الخروج';
$_['text_forgotten']   = 'نسيت كلمة المرور';
$_['text_account']     = 'الحساب';
$_['text_edit']        = 'تحرير الحساب';
$_['text_password']    = 'كلمة المرور';
$_['text_wishlist']    = 'القائمة المفضلة';
$_['text_order']       = 'سجل الطلبات';
$_['text_download']    = 'التحميلات';
$_['text_return']      = 'المنتجات المرجعة';
$_['text_transaction'] = 'التحويلات';
$_['text_newsletter']  = 'النشرة البريدية';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>