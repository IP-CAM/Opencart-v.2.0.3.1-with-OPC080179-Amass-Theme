<?php
// Heading 
$_['heading_title']  = 'الأكثر مبيعاً';

// Text
$_['text_reviews']  = 'من أفضل %s تقييمات.'; 

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>