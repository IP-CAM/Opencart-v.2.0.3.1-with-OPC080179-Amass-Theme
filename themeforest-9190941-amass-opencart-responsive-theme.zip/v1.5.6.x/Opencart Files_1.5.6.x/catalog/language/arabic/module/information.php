<?php
// Heading 
$_['heading_title'] = 'معلومات';

// Text
$_['text_contact']  = 'اتصل بنا';
$_['text_sitemap']  = 'خريطة الموقع';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>