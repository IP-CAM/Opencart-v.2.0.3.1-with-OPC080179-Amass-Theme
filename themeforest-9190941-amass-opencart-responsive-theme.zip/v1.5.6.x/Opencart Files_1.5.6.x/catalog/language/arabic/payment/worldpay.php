<?php
// Heading
$_['heading_title']     = 'شكرا لك على التسوق مع %s .... ';

// Text
$_['text_title']        = 'بطاقة الائتمان / بطاقة الخصم (WorldPay)';
$_['text_response']     = 'رد من WorldPay:';
$_['text_success']      = '... تم بنجاح تحصيل المبلغ الخاص بك.';
$_['text_success_wait'] = '<b><span style="color: #FF0000">الرجاء الانتظار...</span></b> لحين الانتهاء من معالجة طلبك.<br>إذا لم يتم إعادة توجيهك في 10 ثواني، الرجاء النقر <a href="%s">هنا</a>.';
$_['text_failure']      = '... تم إلغاء عملية الدفع!';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">الرجاء الانتظار...</span></b><br>إذا لم يتم إعادة توجيهك في 10 ثواني، الرجاء النقر <a href="%s">هنا</a>.';										  

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>