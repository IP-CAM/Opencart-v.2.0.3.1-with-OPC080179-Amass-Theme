<?php
// Text
$_['text_title']       = 'بطاقة الائتمان / بطاقة (SagePay)';
$_['text_description'] = 'الأصناف في %s رقم الطلب: %s';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>