<?php
// Text
$_['text_title'] = 'paypal اكسبرس (بما فيه بطاقات الائتمان وبطاقات)';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>