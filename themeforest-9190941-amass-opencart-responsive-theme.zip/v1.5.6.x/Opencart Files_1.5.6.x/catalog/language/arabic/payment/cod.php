<?php
// Text
$_['text_title'] = 'الدفع نقداً عند التسليم';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>