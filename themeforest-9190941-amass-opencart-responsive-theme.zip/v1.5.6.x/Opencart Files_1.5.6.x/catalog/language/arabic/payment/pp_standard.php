<?php
// Text
$_['text_title']    = 'PayPal';
$_['text_reason'] 	= 'السبب';
$_['text_testmode']	= 'بوابة الدفع في وضع \'Sandbox Mode\'. لن يتم الخصم من رصيدك.';
$_['text_total']	= 'الشحن, التسليم, التخفيض والضرائب';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>