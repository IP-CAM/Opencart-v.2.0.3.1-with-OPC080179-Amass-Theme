<?php
// Entry
$_['entry_postcode'] = 'الرمز البريدي:';
$_['entry_country']  = 'البلد:';
$_['entry_zone']     = 'المنطقة او المحافظة:';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>