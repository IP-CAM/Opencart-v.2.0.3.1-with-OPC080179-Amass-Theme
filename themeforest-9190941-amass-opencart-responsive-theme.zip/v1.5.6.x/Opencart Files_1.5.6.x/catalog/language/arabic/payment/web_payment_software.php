<?php
// Text
$_['text_title']           = 'بطاقة الائتمان / بطاقة (Web Payment Software)';
$_['text_credit_card']     = 'تفاصيل البطاقة الإتمانية';
$_['text_wait']            = 'يرجى الانتظار!';

// Entry
$_['entry_cc_owner']       = 'مالك البطاقة:';
$_['entry_cc_number']      = 'رقم البطاقة:';
$_['entry_cc_expire_date'] = 'تاريخ انتهاء البطاقة:';
$_['entry_cc_cvv2']        = 'الرمز السري للبطاقة (CVV2):';
?>