<?php
// Heading
$_['heading_title']     = 'شكرا لك على التسوق مع %s .... ';

// Text
$_['text_title']        = 'بطاقة الائتمان / بطاقة (PayPoint)';
$_['text_response']     = 'رد من PayPoint:';
$_['text_success']      = '... تم بنجاح تحصيل المبلغ .';
$_['text_success_wait'] = '<b><span style="color: #FF0000">الرجاء الانتظار...</span></b> لحين الانتهاء من معالجة الطلب.<br>إذا لم يتم إعادة توجيهك في 10 ثواني، الرجاء النقر <a href="%s">هنا</a>.';
$_['text_failure']      = '... تم إلغاء عملية الدفع !';
$_['text_failure_wait'] = '<b><span style="color: #FF0000">الرجاء الانتظار...</span></b><br>إذا لم يتم إعادة توجيهك في 10 ثواني، الرجاء النقر <a href="%s">هنا</a>.';										  

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>