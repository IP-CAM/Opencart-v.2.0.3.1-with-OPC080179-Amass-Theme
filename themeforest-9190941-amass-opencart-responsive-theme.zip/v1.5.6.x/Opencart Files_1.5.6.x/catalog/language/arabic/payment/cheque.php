<?php
// Text
$_['text_title']   = 'شيك أو حوالة';
$_['text_instruction'] = 'شيك أو حوالة';
$_['text_payable'] = 'أدفع إلى: ';
$_['text_address'] = 'أرسل إلى: ';
$_['text_payment'] = 'الطلب لن يشحن حتى يتم استلام المبلغ';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>