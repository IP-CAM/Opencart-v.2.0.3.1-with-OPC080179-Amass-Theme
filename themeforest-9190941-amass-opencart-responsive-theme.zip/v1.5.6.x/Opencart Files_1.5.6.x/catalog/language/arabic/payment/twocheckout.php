<?php
// Text
$_['text_title'] = 'بطاقة الائتمان / بطاقة (2Checkout)';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>