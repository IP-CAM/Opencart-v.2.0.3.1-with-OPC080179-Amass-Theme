<?php
// Text
$_['text_title']           = 'بطاقة الائتمان / بطاقة (Authorize.Net)';
$_['text_credit_card']     = 'تفاصيل البطاقة الائتمانية';
$_['text_wait']            = 'يرجى الانتظار!';

// Entry
$_['entry_cc_owner']       = 'صاحب البطاقة:';
$_['entry_cc_number']      = 'رقم البطاقة:';
$_['entry_cc_expire_date'] = 'تاريخ انتهاء البطاقة:';
$_['entry_cc_cvv2']        = 'الرمز الأمني للبطاقة (CVV2):';

// ####################### Translation By AlfnyHost Team ###########################
// ####################### Website: WWW.alfnyhost.com ##############################
// ####################### E-mail: support@alfnyhost.com ###########################
?>