<?php
// Heading 
$_['heading_title'] = 'Our Products';

$_['tab_latest'] = 'Latest';
$_['tab_bestseller'] = 'Bestseller';
$_['tab_special'] = 'Special';

// Text
$_['text_tax']      = 'Ex Tax:';